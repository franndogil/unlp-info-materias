#!/bin/bash 


echo "El primer parametro es $1"

exit 200
